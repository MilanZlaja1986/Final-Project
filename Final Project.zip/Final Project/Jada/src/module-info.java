/**
 * 
 */
/**
 * @author joonspoon
 *
 */
//module lesson9 {
//	requires junit;
//	requires org.junit.jupiter.api;
//	requires java.desktop;
//}